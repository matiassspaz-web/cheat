#pragma once
#include "entities.hpp"
#include "imgui/imgui.h"
#include <cmath>

struct RadarCfg {
    float scale   = 5.f;    // metros por pixel
    float size    = 200.f;  // tamaño del radar en px
    ImVec2 pos    = {10.f, 10.f};
};

void draw_radar(const EntityList& el, const Memory& mem, const RadarCfg& cfg) {
    uintptr_t local = mem.read<uintptr_t>(mem.client + offsets::dwLocalPlayerPawn);
    Vector3   lpos  = mem.read<Vector3>(local + offsets::m_vOldOrigin);

    auto* draw = ImGui::GetWindowDrawList();
    ImVec2 center = { cfg.pos.x + cfg.size/2, cfg.pos.y + cfg.size/2 };

    // fondo
    draw->AddRectFilled(
        {cfg.pos.x, cfg.pos.y},
        {cfg.pos.x + cfg.size, cfg.pos.y + cfg.size},
        IM_COL32(0, 0, 0, 160), 4.f
    );
    draw->AddRect(
        {cfg.pos.x, cfg.pos.y},
        {cfg.pos.x + cfg.size, cfg.pos.y + cfg.size},
        IM_COL32(100, 100, 100, 200), 4.f
    );

    // local player (punto blanco en centro)
    draw->AddCircleFilled(center, 4.f, IM_COL32(255, 255, 255, 255));

    for (int i = 0; i < el.count; i++) {
        const auto& p = el.players[i];

        float dx = (p.origin.x - lpos.x) / cfg.scale;
        float dy = (p.origin.y - lpos.y) / cfg.scale;

        // clamp al borde
        float dist = sqrtf(dx*dx + dy*dy);
        float max_r = cfg.size / 2.f - 6.f;
        if (dist > max_r) {
            dx = dx / dist * max_r;
            dy = dy / dist * max_r;
        }

        ImVec2 dot = { center.x + dx, center.y - dy };

        // rojo = enemigo
        draw->AddCircleFilled(dot, 4.f, IM_COL32(255, 50, 50, 230));

        // línea desde centro
        draw->AddLine(center, dot, IM_COL32(255, 50, 50, 80), 1.f);
    }
}