#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <stdexcept>

class Memory {
public:
    HANDLE      handle = nullptr;
    uintptr_t   base   = 0;
    uintptr_t   client = 0;

    Memory() {
        DWORD pid = get_pid(L"cs2.exe");
        if (!pid) throw std::runtime_error("cs2.exe no encontrado");

        handle = OpenProcess(PROCESS_VM_READ, FALSE, pid);
        if (!handle) throw std::runtime_error("OpenProcess fallo");

        client = get_module(pid, L"client.dll");
        if (!client) throw std::runtime_error("client.dll no encontrado");
    }

    ~Memory() { if (handle) CloseHandle(handle); }

    template<typename T>
    T read(uintptr_t addr) const {
        T val{};
        ReadProcessMemory(handle, reinterpret_cast<LPCVOID>(addr), &val, sizeof(T), nullptr);
        return val;
    }

private:
    DWORD get_pid(const wchar_t* name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32W pe{ sizeof(pe) };
        while (Process32NextW(snap, &pe))
            if (!_wcsicmp(pe.szExeFile, name)) {
                CloseHandle(snap);
                return pe.th32ProcessID;
            }
        CloseHandle(snap);
        return 0;
    }

    uintptr_t get_module(DWORD pid, const wchar_t* name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
        MODULEENTRY32W me{ sizeof(me) };
        while (Module32NextW(snap, &me))
            if (!_wcsicmp(me.szModule, name)) {
                CloseHandle(snap);
                return reinterpret_cast<uintptr_t>(me.modBaseAddr);
            }
        CloseHandle(snap);
        return 0;
    }
};