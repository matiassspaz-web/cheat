#pragma once
#include <cstdint>

namespace offsets {
    // client.dll
    constexpr uintptr_t dwEntityList        = 0x18C3BB8;
    constexpr uintptr_t dwLocalPlayerPawn   = 0x17370C8;
    constexpr uintptr_t dwViewMatrix        = 0x19238A0;
    constexpr uintptr_t dwPlantedC4         = 0x18C5AE8;

    // entity
    constexpr uintptr_t m_iHealth           = 0x344;
    constexpr uintptr_t m_iTeamNum          = 0x3CB;
    constexpr uintptr_t m_bPawnIsAlive      = 0x33C;
    constexpr uintptr_t m_vOldOrigin        = 0x1324;
    constexpr uintptr_t m_pGameSceneNode    = 0x328;
    constexpr uintptr_t m_modelState        = 0x160;
    constexpr uintptr_t m_boneArray         = 0x80;  // dentro de modelState
    constexpr uintptr_t m_iIDEntIndex       = 0x7CC;
    constexpr uintptr_t m_flFlashDuration   = 0x1198;
}

namespace bones {
    constexpr int HEAD  = 6;
    constexpr int NECK  = 5;
    constexpr int CHEST = 4;
    constexpr int PELVIS= 0;
}