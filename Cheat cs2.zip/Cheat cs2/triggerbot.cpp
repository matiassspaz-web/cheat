#pragma once
#include "memory.hpp"
#include "offsets.hpp"
#include <Windows.h>
#include <thread>
#include <chrono>

struct TriggerCfg {
    bool  enabled    = false;
    int   delay_ms   = 10;   // delay antes de disparar (anti-detección mínima)
    bool  team_check = true;
};

void triggerbot_tick(const Memory& mem, int local_team, const TriggerCfg& cfg) {
    if (!cfg.enabled) return;

    uintptr_t local = mem.read<uintptr_t>(mem.client + offsets::dwLocalPlayerPawn);
    int entity_id   = mem.read<int>(local + offsets::m_iIDEntIndex);

    if (entity_id <= 0) return;

    uintptr_t entity_list = mem.read<uintptr_t>(mem.client + offsets::dwEntityList);
    uintptr_t list_entry  = mem.read<uintptr_t>(entity_list + ((entity_id + 1) << 3));
    if (!list_entry) return;

    uintptr_t pawn   = mem.read<uintptr_t>(list_entry + 0x78);
    int team         = mem.read<int>(pawn + offsets::m_iTeamNum);
    bool alive       = mem.read<bool>(pawn + offsets::m_bPawnIsAlive);

    if (!alive) return;
    if (cfg.team_check && team == local_team) return;

    std::this_thread::sleep_for(std::chrono::milliseconds(cfg.delay_ms));

    INPUT inp{};
    inp.type       = INPUT_MOUSE;
    inp.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    SendInput(1, &inp, sizeof(INPUT));

    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    inp.mi.dwFlags = MOUSEEVENTF_LEFTUP;
    SendInput(1, &inp, sizeof(INPUT));
}