#pragma once
#include "entities.hpp"
#include "memory.hpp"
#include "offsets.hpp"
#include <Windows.h>
#include <cmath>

struct AimbotCfg {
    float fov      = 5.f;    // grados desde crosshair
    float smooth   = 8.f;    // 1 = instant, mayor = más suave
    bool  head_only= true;
    bool  enabled  = false;
};

// distancia angular entre dos puntos screen
float calc_fov(float cx, float cy, float tx, float ty) {
    float dx = tx - cx;
    float dy = ty - cy;
    return sqrtf(dx*dx + dy*dy);
}

void aimbot_tick(const EntityList& el, const Matrix4x4& vm,
                 int sw, int sh, const AimbotCfg& cfg)
{
    if (!cfg.enabled) return;
    // solo actúa si botón derecho (ADS) está presionado
    if (!(GetAsyncKeyState(VK_RBUTTON) & 0x8000)) return;

    float  best_fov = cfg.fov * (sw / 1920.f) * 100.f; // escalar a pixels
    int    best_idx = -1;
    Vector2 best_screen{};

    float cx = sw / 2.f;
    float cy = sh / 2.f;

    for (int i = 0; i < el.count; i++) {
        Vector3 target = cfg.head_only
            ? el.players[i].head_pos
            : el.players[i].origin;

        // subir un poco el origen para chest
        if (!cfg.head_only) target.z += 60.f;

        Vector2 screen;
        // reusar w2s definida en esp.cpp — extern inline en impl real
        float w = vm.m[3][0]*target.x + vm.m[3][1]*target.y +
                  vm.m[3][2]*target.z + vm.m[3][3];
        if (w < 0.001f) continue;
        float x = vm.m[0][0]*target.x + vm.m[0][1]*target.y +
                  vm.m[0][2]*target.z + vm.m[0][3];
        float y = vm.m[1][0]*target.x + vm.m[1][1]*target.y +
                  vm.m[1][2]*target.z + vm.m[1][3];
        screen.x = cx + cx * x / w;
        screen.y = cy - cy * y / w;

        float dist = calc_fov(cx, cy, screen.x, screen.y);
        if (dist < best_fov) {
            best_fov   = dist;
            best_idx   = i;
            best_screen = screen;
        }
    }

    if (best_idx < 0) return;

    float dx = (best_screen.x - cx) / cfg.smooth;
    float dy = (best_screen.y - cy) / cfg.smooth;

    INPUT inp{};
    inp.type       = INPUT_MOUSE;
    inp.mi.dwFlags = MOUSEEVENTF_MOVE;
    inp.mi.dx      = static_cast<LONG>(dx);
    inp.mi.dy      = static_cast<LONG>(dy);
    SendInput(1, &inp, sizeof(INPUT));
}