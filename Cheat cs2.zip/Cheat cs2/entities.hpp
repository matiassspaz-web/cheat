#pragma once
#include "memory.hpp"
#include "offsets.hpp"
#include <array>

struct Vector3 {
    float x, y, z;
    Vector3 operator-(const Vector3& o) const { return { x-o.x, y-o.y, z-o.z }; }
    float length() const { return sqrtf(x*x + y*y + z*z); }
};

struct Vector2 { float x, y; };

struct Matrix4x4 { float m[4][4]; };

struct Player {
    uintptr_t ptr      = 0;
    int       health   = 0;
    int       team     = 0;
    bool      alive    = false;
    Vector3   origin   = {};
    Vector3   head_pos = {};
    uintptr_t bone_ptr = 0;
};

class EntityList {
public:
    static constexpr int MAX_PLAYERS = 64;

    std::array<Player, MAX_PLAYERS> players{};
    int local_team = 0;
    int count      = 0;

    void update(const Memory& mem) {
        count = 0;
        uintptr_t entity_list = mem.read<uintptr_t>(mem.client + offsets::dwEntityList);
        uintptr_t local_pawn  = mem.read<uintptr_t>(mem.client + offsets::dwLocalPlayerPawn);
        local_team            = mem.read<int>(local_pawn + offsets::m_iTeamNum);

        for (int i = 1; i < MAX_PLAYERS; i++) {
            uintptr_t list_entry = mem.read<uintptr_t>(entity_list + ((i + 1) << 3));
            if (!list_entry) continue;

            uintptr_t pawn = mem.read<uintptr_t>(list_entry + 0x78);
            if (!pawn) continue;

            Player p;
            p.ptr    = pawn;
            p.health = mem.read<int>(pawn + offsets::m_iHealth);
            p.team   = mem.read<int>(pawn + offsets::m_iTeamNum);
            p.alive  = mem.read<bool>(pawn + offsets::m_bPawnIsAlive);

            if (!p.alive || p.health <= 0 || p.team == local_team) continue;

            p.origin = mem.read<Vector3>(pawn + offsets::m_vOldOrigin);

            // bone head
            uintptr_t scene  = mem.read<uintptr_t>(pawn + offsets::m_pGameSceneNode);
            uintptr_t bones  = mem.read<uintptr_t>(scene + offsets::m_modelState + offsets::m_boneArray);
            p.bone_ptr       = bones;
            p.head_pos       = mem.read<Vector3>(bones + bones::HEAD * 32);

            players[count++] = p;
        }
    }
};