#pragma once
#include "entities.hpp"
#include "overlay.hpp"
#include "imgui/imgui.h"
#include <cmath>

// world to screen
bool w2s(const Vector3& pos, const Matrix4x4& vm, int sw, int sh, Vector2& out) {
    float w = vm.m[3][0]*pos.x + vm.m[3][1]*pos.y + vm.m[3][2]*pos.z + vm.m[3][3];
    if (w < 0.001f) return false;
    float x = vm.m[0][0]*pos.x + vm.m[0][1]*pos.y + vm.m[0][2]*pos.z + vm.m[0][3];
    float y = vm.m[1][0]*pos.x + vm.m[1][1]*pos.y + vm.m[1][2]*pos.z + vm.m[1][3];
    out.x = (sw / 2.f) + (sw / 2.f) * x / w;
    out.y = (sh / 2.f) - (sh / 2.f) * y / w;
    return true;
}

void draw_esp(const EntityList& el, const Matrix4x4& vm, int sw, int sh) {
    auto* draw = ImGui::GetWindowDrawList();

    for (int i = 0; i < el.count; i++) {
        const auto& p = el.players[i];

        Vector2 head_s, feet_s;
        if (!w2s(p.head_pos, vm, sw, sh, head_s)) continue;
        if (!w2s(p.origin,   vm, sw, sh, feet_s)) continue;

        float height = feet_s.y - head_s.y;
        float width  = height * 0.4f;

        // color por health
        float r = 1.f - (p.health / 100.f);
        float g = p.health / 100.f;
        ImU32 col = IM_COL32(
            (int)(r * 255), (int)(g * 255), 0, 220
        );

        // bounding box
        draw->AddRect(
            {head_s.x - width/2, head_s.y},
            {head_s.x + width/2, feet_s.y},
            col, 0.f, 0, 1.5f
        );

        // health bar lateral
        float bar_x = head_s.x - width/2 - 6;
        float bar_h = height * (p.health / 100.f);
        draw->AddRectFilled(
            {bar_x - 2, head_s.y},
            {bar_x + 2, feet_s.y},
            IM_COL32(50, 50, 50, 180)
        );
        draw->AddRectFilled(
            {bar_x - 2, feet_s.y - bar_h},
            {bar_x + 2, feet_s.y},
            col
        );

        // nombre placeholder + health text
        char info[32];
        snprintf(info, sizeof(info), "HP: %d", p.health);
        draw->AddText({head_s.x - 15, head_s.y - 14}, IM_COL32(255,255,255,200), info);

        // snap line (pies)
        draw->AddLine({(float)sw/2, (float)sh}, {feet_s.x, feet_s.y},
            IM_COL32(255, 50, 50, 100), 1.f);
    }
}