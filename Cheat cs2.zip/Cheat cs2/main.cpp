#include "memory.hpp"
#include "entities.hpp"
#include "overlay.hpp"
#include "esp.cpp"
#include "aimbot.cpp"
#include "triggerbot.cpp"
#include "radar.cpp"
#include "offsets.hpp"
#include <thread>
#include <chrono>

// ——— config global ———
AimbotCfg  aim_cfg;
TriggerCfg trig_cfg;
RadarCfg   radar_cfg;

// toggle hotkeys (INSERT = menú, F1-F4 = módulos)
void handle_hotkeys(bool& show_menu) {
    static bool ins_prev = false;
    bool ins_now = GetAsyncKeyState(VK_INSERT) & 0x8000;
    if (ins_now && !ins_prev) show_menu = !show_menu;
    ins_prev = ins_now;

    if (GetAsyncKeyState(VK_F1) & 0x1) aim_cfg.enabled  = !aim_cfg.enabled;
    if (GetAsyncKeyState(VK_F2) & 0x1) trig_cfg.enabled = !trig_cfg.enabled;
}

void draw_menu() {
    ImGui::SetNextWindowSize({320, 280}, ImGuiCond_Once);
    ImGui::SetNextWindowPos({100, 100},  ImGuiCond_Once);
    ImGui::Begin("CS2 External", nullptr, ImGuiWindowFlags_NoCollapse);

    if (ImGui::BeginTabBar("tabs")) {

        if (ImGui::BeginTabItem("Aimbot")) {
            ImGui::Checkbox("Enabled (F1)",   &aim_cfg.enabled);
            ImGui::Checkbox("Head only",      &aim_cfg.head_only);
            ImGui::SliderFloat("FOV",         &aim_cfg.fov,    1.f, 20.f);
            ImGui::SliderFloat("Smooth",      &aim_cfg.smooth, 1.f, 30.f);
            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("Triggerbot")) {
            ImGui::Checkbox("Enabled (F2)",   &trig_cfg.enabled);
            ImGui::Checkbox("Team check",     &trig_cfg.team_check);
            ImGui::SliderInt("Delay (ms)",    &trig_cfg.delay_ms, 0, 100);
            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("Radar")) {
            ImGui::SliderFloat("Scale",       &radar_cfg.scale, 1.f, 20.f);
            ImGui::SliderFloat("Size",        &radar_cfg.size,  100.f, 400.f);
            ImGui::EndTabItem();
        }

        ImGui::EndTabBar();
    }
    ImGui::End();
}

int main() {
    Memory mem;
    EntityList entities;
    Overlay overlay;

    if (!overlay.init()) return 1;

    bool show_menu = true;

    while (true) {
        // leer entidades
        entities.update(mem);

        // view matrix
        Matrix4x4 vm = mem.read<Matrix4x4>(mem.client + offsets::dwViewMatrix);

        // hotkeys
        handle_hotkeys(show_menu);

        // frame
        overlay.begin_frame();

        // ESP siempre activo
        draw_esp(entities, vm, overlay.width, overlay.height);

        // radar siempre activo
        draw_radar(entities, mem, radar_cfg);

        // aimbot
        aimbot_tick(entities, vm, overlay.width, overlay.height, aim_cfg);

        // triggerbot
        {
            uintptr_t local = mem.read<uintptr_t>(mem.client + offsets::dwLocalPlayerPawn);
            int local_team  = mem.read<int>(local + offsets::m_iTeamNum);
            triggerbot_tick(mem, local_team, trig_cfg);
        }

        // menú (INSERT para toggle)
        if (show_menu) draw_menu();

        overlay.end_frame();

        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}