#pragma once
#include <d3d11.h>
#include <dxgi.h>
#include <Windows.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

// ImGui — asumimos que está linkeado
#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx11.h"
#include "imgui/imgui_impl_win32.h"

class Overlay {
public:
    HWND        hwnd      = nullptr;
    int         width     = GetSystemMetrics(SM_CXSCREEN);
    int         height    = GetSystemMetrics(SM_CYSCREEN);

    ID3D11Device*           device    = nullptr;
    ID3D11DeviceContext*    ctx       = nullptr;
    IDXGISwapChain*         swap      = nullptr;
    ID3D11RenderTargetView* rtv       = nullptr;

    bool init() {
        WNDCLASSEXW wc{};
        wc.cbSize        = sizeof(wc);
        wc.lpfnWndProc   = DefWindowProcW;
        wc.lpszClassName = L"cs2_ext_overlay";
        wc.hInstance     = GetModuleHandle(nullptr);
        RegisterClassExW(&wc);

        hwnd = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW,
            L"cs2_ext_overlay", L"",
            WS_POPUP,
            0, 0, width, height,
            nullptr, nullptr, wc.hInstance, nullptr
        );

        SetLayeredWindowAttributes(hwnd, RGB(0,0,0), 0, LWA_COLORKEY);
        ShowWindow(hwnd, SW_SHOW);

        // === STREAM PROOF ===
        SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);

        return init_dx11();
    }

    void begin_frame() {
        MSG msg;
        while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
            DispatchMessage(&msg);

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // ventana invisible fullscreen para draw
        ImGui::SetNextWindowPos({0,0});
        ImGui::SetNextWindowSize({(float)width, (float)height});
        ImGui::Begin("##overlay", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground |
            ImGuiWindowFlags_NoInputs   | ImGuiWindowFlags_NoNav        |
            ImGuiWindowFlags_NoBringToFrontOnFocus);
    }

    void end_frame() {
        ImGui::End();
        ImGui::Render();
        const float clear[4] = {0,0,0,0};
        ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ctx->ClearRenderTargetView(rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        swap->Present(0, 0);
    }

private:
    bool init_dx11() {
        DXGI_SWAP_CHAIN_DESC sd{};
        sd.BufferCount                        = 2;
        sd.BufferDesc.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferDesc.Width                   = width;
        sd.BufferDesc.Height                  = height;
        sd.BufferUsage                        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow                       = hwnd;
        sd.SampleDesc.Count                   = 1;
        sd.Windowed                           = TRUE;
        sd.SwapEffect                         = DXGI_SWAP_EFFECT_DISCARD;

        D3D_FEATURE_LEVEL fl;
        D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            nullptr, 0, D3D11_SDK_VERSION,
            &sd, &swap, &device, &fl, &ctx
        );

        ID3D11Texture2D* back = nullptr;
        swap->GetBuffer(0, IID_PPV_ARGS(&back));
        device->CreateRenderTargetView(back, nullptr, &rtv);
        back->Release();

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGui_ImplWin32_Init(hwnd);
        ImGui_ImplDX11_Init(device, ctx);
        ImGui::StyleColorsDark();
        return true;
    }
};